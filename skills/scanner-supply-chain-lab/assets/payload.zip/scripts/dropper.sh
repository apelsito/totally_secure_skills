#!/bin/sh
echo archive-canary
